package Prashant;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PageObjects.portalLoginPage;
import Resources.Base;

public class HomePageAboutUsTest extends Base{       //inheritating all the methods from base class
	
	public static Logger log = LogManager.getLogger(Base.class.getName());

	@BeforeTest
	public void intialize() throws IOException
	{
         driver = initializeDriver();
			
	}
	@Test
	public void MainHomePage()  throws IOException
	{
		driver.get(prop.getProperty("url"));  //We defined it here just because we have to access 2 time this site for different set of credentials 
		
		// one is inheritance
		// creating object to that class and invoke methods of it
	
		portalLoginPage au = new portalLoginPage(driver);
		Actions action = new Actions(driver);
		action.moveToElement(au.LearnHover()).build().perform();
		
		Actions action2 = new Actions(driver);
		action2.moveToElement(au.Styling()).click().build().perform();
		
		Assert.assertEquals(au.Title().getText() ,"FACIAL HAIR STYLES");
		log.info("TestCases passesd matched the textTitle");
	}	
		
		@AfterTest
		public void  teardown()
		{
			driver.close();
			driver = null;
		}
	}
	
