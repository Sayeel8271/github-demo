package Prashant;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PageObjects.LandingPage;
import Resources.Base;

public class HomePage extends Base{       //inheritating all the methods from base class
	
	public static Logger log = LogManager.getLogger(Base.class.getName());

	@BeforeTest
	public void intialize() throws IOException
	{
         driver = initializeDriver();			
	}
	
	@Test
	public void MainHomePage()  throws IOException
	{
		driver.get(prop.getProperty("url"));      //We defined it here just because we have to access 2 time this site for different set of credentials 
	
		LandingPage l = new LandingPage(driver);
		Actions action = new Actions(driver);
		action.moveToElement(l.HoverOnProduct()).build().perform();
		Actions action2 = new Actions(driver);
		action2.moveToElement(l.MACCH3()).click().build().perform();
		log.info("TestCases passesd");

	//	Assert.assertEquals(l.TextOfProduct().getText() , "Liability Only - Two Wheeler & Private Car");
		
	}
		@AfterTest
		public void  teardown()
		{
			driver.close();
			driver = null;
		}		
	}
