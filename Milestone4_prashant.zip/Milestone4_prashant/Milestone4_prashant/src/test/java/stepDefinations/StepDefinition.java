package stepDefinations;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;

import org.junit.runner.RunWith;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import PageObjects.LandingPage;
import PageObjects.LoginPage;
import Resources.Base;



@RunWith(Cucumber.class)
public class StepDefinition extends Base{

	@Given("^Initialize the browser$")
	public void Initialize_the_browser_with_chrome() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 driver = initializeDriver();    
	}

	 @Given("^Navigate to site$")
	    public void Navigate_to_Site() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		 driver.get(prop.getProperty("url"));
			
	 }
	 
	 @When("^User enters (.+) search for the product$")
		public void User_enters_search_for_the_product(String arg1) throws Throwable {
		LoginPage lp = new LoginPage(driver);
		lp.Search().click();
		lp.SearchInputText().sendKeys(arg1);
		lp.ClickForSearch().click();	 
				
		}
	 
	
	 @When("^The user navigate to 2nd page")
	public void The_user_navigate_to_2nd_page() throws Throwable {	      
		System.out.println(driver.getTitle());
	}


    @Then("^User checks for the razor text$")
    public void User_checks_for_the_Gillette_MACH3__Turbo() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
    	LoginPage lp = new LoginPage(driver);
    	Assert.assertEquals(lp.TitleText().getText() ,"Results For \"Razor\"");
    }
    
    @And("^Close browsers$")
    public void Close_browsers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
    	driver.quit();
    }
}