package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class portalLoginPage {

	public WebDriver driver;
	
	By Learn = By.xpath("//*[@id=\"headerMenu\"]/div/nav/div/div[1]/button/span");
	By styling = By.xpath("//*[@id=\"headerMenu\"]/div/nav/div/div[1]/div/div/div/div/div[1]/div[1]/a");
	By Title = By.xpath("//*[@id=\"tabItem_1\"]/h2");

	public portalLoginPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	this.driver = driver;
	}


	public WebElement LearnHover()
	{
		return driver.findElement(Learn);
	}
	
	public WebElement Styling()
	{
		return driver.findElement(styling);
	}
	public WebElement Title()
	{
		return driver.findElement(Title);
	}
	
	
	
}
