package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	public WebDriver driver;
	
	By Search = By.id("searchIconId");
	By SearchText = By.id("search-box-input");
	By FinalSearch = By.id("searchIconId");
	
	By TitleText = By.xpath("//*[@id=\"main-content\"]/div/h1");
	
	
	
	public LoginPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	this.driver = driver;
	}


	public WebElement Search()
	{
		return driver.findElement(Search);
	}
	
	public WebElement SearchInputText()
	{
		return driver.findElement(SearchText);
	}
	
	public WebElement ClickForSearch()
	{
		return driver.findElement(FinalSearch);
	}
	public WebElement TitleText()
	{
		return driver.findElement(TitleText);
	}
	
}
