package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {

	public WebDriver driver;
	
	By product = By.xpath("//*[@id=\"headerMenu\"]/div/nav/div/div[2]/button/span");
	By Macch = By.xpath("//*[@id=\"headerMenu\"]/div/nav/div/div[2]/div/div/div/div/div[1]/div[1]/a[3]");
	By click = By.xpath("//*[@id=\"main-content\"]/div/div[4]/div/div[1]/div/div[1]/div/div");
	By text = By.xpath("//*[@id=\"overview\"]/div/div/div/div[2]/h1");
    
	public LandingPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	this.driver = driver;
	}


	public WebElement HoverOnProduct()
	{
		return driver.findElement(product);
	}
	
	public WebElement MACCH3()
	{
		return driver.findElement(Macch);
	}
	public WebElement Explore()
	{
		return driver.findElement(click);
	}
	
	
	  public WebElement TextOfProduct()
	  { 
		  return driver.findElement(text); 
	  }
	 
	
}
